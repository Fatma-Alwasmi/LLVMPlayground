#include <stdio.h>
int main(void){
	int a, b ,c, d;
	a = getchar();
	b = 0;
	c = (a != b);
	d = b/c;

	return 0;
}
